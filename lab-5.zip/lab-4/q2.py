import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_percentage_error, r2_score

# --- Step 1: Helper function to parse volume strings ---
def parse_volume(vol_str):
    if isinstance(vol_str, str):
        if 'M' in vol_str:
            return float(vol_str.replace('M', '')) * 1_000_000
        elif 'K' in vol_str:
            return float(vol_str.replace('K', '')) * 1_000
        else:
            return float(vol_str.replace(',', ''))
    return vol_str

# --- Step 2: Load and preprocess data ---
def load_data(filepath, sheet_name):
    df = pd.read_excel(filepath, sheet_name=sheet_name)
    df['Volume'] = df['Volume'].apply(parse_volume)
    X = df[['Open', 'High', 'Low', 'Volume']]
    y = df['Price']
    return X, y

# --- Step 3: Train the regression model ---
def train_model(X_train, y_train):
    model = LinearRegression()
    model.fit(X_train, y_train)
    return model

# --- Step 4: Evaluate model performance ---
def evaluate_model(model, X_test, y_test):
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    rmse = mse ** 0.5
    mape = mean_absolute_percentage_error(y_test, y_pred) * 100
    r2 = r2_score(y_test, y_pred)
    return mse, rmse, mape, r2

# --- Step 5: Main execution flow ---
def main():
    filepath = 'Lab_Session_Data.xlsx'
    sheet_name = 'IRCTC Stock Price'

    X, y = load_data(filepath, sheet_name)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = train_model(X_train, y_train)
    mse, rmse, mape, r2 = evaluate_model(model, X_test, y_test)

    print("Mean Squared Error (MSE):", mse)
    print("Root Mean Squared Error (RMSE):", rmse)
    print("Mean Absolute Percentage Error (MAPE):", mape, "%")
    print("R² Score:", r2)


if __name__ == "__main__":
    main()
