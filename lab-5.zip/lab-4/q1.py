import os
import cv2
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report


# Load and preprocess image dataset

def load_images_from_folder(folder_path='defungi', image_size=(64, 64)):
    features = []
    labels = []

    for class_name in sorted(os.listdir(folder_path)):
        class_path = os.path.join(folder_path, class_name)
        if not os.path.isdir(class_path):
            continue

        for img_file in os.listdir(class_path):
            img_path = os.path.join(class_path, img_file)
            img = cv2.imread(img_path)
            if img is None:
                continue
            img = cv2.resize(img, image_size)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            img = img.astype(np.float32) / 255.0  # Normalize
            img_flatten = img.flatten()
            features.append(img_flatten)
            labels.append(class_name)

    return np.array(features), np.array(labels)

# Main execution

def main():
    # Load the dataset
    X, y = load_images_from_folder('defungi')

    # Encode class labels to integers
    le = LabelEncoder()
    y_encoded = le.fit_transform(y)

    # Split into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_encoded, test_size=0.3, stratify=y_encoded, random_state=42
    )

    # Create and train the kNN classifier using neigh.fit
    neigh = KNeighborsClassifier(n_neighbors=3)
    neigh.fit(X_train, y_train)

    # Use neigh.score to evaluate the model
    accuracy = neigh.score(X_test, y_test)

    # Predict class labels for test data
    y_pred = neigh.predict(X_test)

    print("Train Report:")
    print(classification_report(y_train, neigh.predict(X_train)))

    print("Test Report:")
    print(classification_report(y_test, neigh.predict(X_test)))

    # Print results
    print("\n--- kNN Classifier Results (k=3) ---")
    print(f"Accuracy (using neigh.score): {accuracy * 100:.2f}%")
    
# Run the program
if __name__ == "__main__":
    main()
    