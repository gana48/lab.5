import os
import cv2
import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler

# --- Step A3: Extract features from 20 samples per class ---
def extract_features_two_classes_limited(dataset_path, samples_per_class=20):
    features = []
    labels = []
    class_names = sorted([d for d in os.listdir(dataset_path) if os.path.isdir(os.path.join(dataset_path, d))])[:2]

    for class_label, class_folder in enumerate(class_names):
        folder_path = os.path.join(dataset_path, class_folder)
        image_files = [f for f in os.listdir(folder_path) if f.lower().endswith(('.jpg', '.png', '.jpeg'))]
        image_files = image_files[:samples_per_class]  # Take only 20 files

        for file in image_files:
            img_path = os.path.join(folder_path, file)
            img = cv2.imread(img_path)
            if img is None:
                continue
            img = cv2.resize(img, (64, 64))
            mean_colors = img.mean(axis=(0, 1))  # BGR
            red = mean_colors[2]
            green = mean_colors[1]
            features.append([red, green])
            labels.append(class_label)

    return np.array(features), np.array(labels), class_names

# Generate test grid
def generate_test_grid(step=2):
    x_vals = np.arange(0, 256, step)
    y_vals = np.arange(0, 256, step)
    xx, yy = np.meshgrid(x_vals, y_vals)
    test_points = np.c_[xx.ravel(), yy.ravel()]
    return test_points, xx, yy

# Plot decision boundary
def plot_decision_boundary(test_points, y_pred, xx, yy, k, X_train, y_train, class_names):
    Z = y_pred.reshape(xx.shape)
    plt.contourf(xx, yy, Z, alpha=0.3, cmap=plt.cm.RdBu)
    plt.contour(xx, yy, Z, levels=[0.5], colors='black', linewidths=1)

    for i, class_name in enumerate(class_names):
        plt.scatter(X_train[y_train == i, 0], X_train[y_train == i, 1],
                    label=class_name, s=60, edgecolors='k')

    plt.xlabel("Average Red")
    plt.ylabel("Average Green")
    plt.title(f"k = {k}")
    plt.legend()
    plt.grid(True)

# --- Main function: A3–A5 ---
def main():
    dataset_path = "defungi"  # ⚠️ Update this if needed

    # Load only 20 samples per class
    X_train, y_train, class_names = extract_features_two_classes_limited(dataset_path, samples_per_class=20)

    # Scale for better distance accuracy
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)

    # Test grid
    test_points, xx, yy = generate_test_grid(step=2)
    test_points_scaled = scaler.transform(test_points)

    # Plot for different k
    k_values = [1, 3, 5, 10]
    fig, axs = plt.subplots(2, 2, figsize=(14, 12))
    axs = axs.ravel()

    for i, k in enumerate(k_values):
        model = KNeighborsClassifier(n_neighbors=k)
        model.fit(X_train_scaled, y_train)
        y_pred = model.predict(test_points_scaled)

        plt.sca(axs[i])
        plot_decision_boundary(test_points, y_pred, xx, yy, k, X_train, y_train, class_names)

    plt.suptitle("k-NN Decision Boundaries (20 Samples per Class)", fontsize=16)
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.show()

# Run
if __name__ == "__main__":
    main()
