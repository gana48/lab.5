import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier

# --- Step 1: Generate training data ---
def generate_training_data(num_points=20, low=1, high=10, seed=42):
    np.random.seed(seed)
    X_train = np.random.uniform(low, high, size=(num_points, 2))
    y_train = np.where(X_train[:, 0] > X_train[:, 1], 0, 1)  # Class 0 if X > Y, else 1
    return X_train, y_train

# --- Step 2: Generate test data as a grid ---
def generate_test_data(step=0.1):
    x_vals = np.arange(0, 10 + step, step)
    y_vals = np.arange(0, 10 + step, step)
    xx, yy = np.meshgrid(x_vals, y_vals)
    test_points = np.c_[xx.ravel(), yy.ravel()]
    return test_points, xx, yy

# --- Step 3: Train k-NN classifier ---
def train_knn(X_train, y_train, k=3):
    model = KNeighborsClassifier(n_neighbors=k)
    model.fit(X_train, y_train)
    return model

# --- Step 4: Predict classes for test data ---
def predict_test(model, test_points):
    y_pred = model.predict(test_points)
    return y_pred

# --- Step 5: Plot predicted test data points as class-colored scatter plot ---
def plot_decision_boundary(test_points, y_pred, xx, yy):
    Z = y_pred.reshape(xx.shape)

    plt.figure(figsize=(10, 8))

    # 1. Color regions by predicted class
    plt.contourf(xx, yy, Z, alpha=0.3, cmap=plt.cm.RdBu)

    # 2. Draw the actual class boundary line (decision contour where class switches)
    plt.contour(xx, yy, Z, levels=[0.5], colors='black', linewidths=2)

    # 3. Scatter test points (optional: for dense points, you may skip this)
    plt.scatter(test_points[:, 0], test_points[:, 1], c=y_pred, cmap=plt.cm.RdBu, s=2)

    plt.xlabel("Feature X")
    plt.ylabel("Feature Y")
    plt.title("k-NN Decision Boundary with Class Separation Line (k=3)")
    plt.grid(True)
    plt.show()


# --- Main Execution ---
def main():
    # Generate training and test data
    X_train, y_train = generate_training_data()
    test_points, xx, yy = generate_test_data()

    # Train and predict
    knn_model = train_knn(X_train, y_train, k=3)
    y_test_pred = predict_test(knn_model, test_points)

    # Plot result
    plot_decision_boundary(test_points, y_test_pred, xx, yy)

# --- Run program ---
if __name__ == "__main__":
    main()
