import numpy as np
import matplotlib.pyplot as plt

# --- Step 1: Generate random data ---
def generate_data(num_points=20, low=1, high=10, seed=42):
    np.random.seed(seed)
    data = np.random.uniform(low, high, size=(num_points, 2))  # shape: (num_points, 2)
    return data

# --- Step 2: Assign classes (class0 = Blue, class1 = Red) ---
def assign_classes(data):
    # Class 0 if X > Y, else Class 1
    labels = np.where(data[:, 0] > data[:, 1], 0, 1)
    return labels

# --- Step 3: Plot the scatter plot with class colors ---
def plot_data(data, labels):
    colors = ['blue' if label == 0 else 'red' for label in labels]
    plt.figure(figsize=(8, 6))
    plt.scatter(data[:, 0], data[:, 1], c=colors, s=100, edgecolors='k')
    plt.xlabel("Feature X")
    plt.ylabel("Feature Y")
    plt.title("Scatter Plot of Randomly Generated Data (2 Classes)")
    plt.grid(True)
    plt.show()

# --- Step 4: Main execution ---
def main():
    data = generate_data()
    labels = assign_classes(data)
    plot_data(data, labels)

# --- Run the program ---
if __name__ == "__main__":
    main()
