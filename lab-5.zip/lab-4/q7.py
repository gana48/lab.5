import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

# Step 1: Data Generation
def generate_data(samples=300, features=4, informative=3, classes=3, random_state=42):
    X, y = make_classification(
        n_samples=samples,
        n_features=features,
        n_informative=informative,
        n_redundant=0,
        n_classes=classes,
        random_state=random_state
    )
    return X, y

# Step 2: Data Splitting
def split_data(X, y, test_size=0.3, random_state=42):
    return train_test_split(X, y, test_size=test_size, random_state=random_state)

# Step 3: Data Scaling
def scale_data(X_train, X_test):
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    return X_train_scaled, X_test_scaled, scaler

# Step 4: Grid Search for Best K
def tune_hyperparameters(X_train, y_train, k_range=range(1, 31)):
    knn = KNeighborsClassifier()
    param_grid = {'n_neighbors': list(k_range)}
    grid_search = GridSearchCV(knn, param_grid, cv=5, scoring='accuracy')
    grid_search.fit(X_train, y_train)
    return grid_search

# Step 5: Model Evaluation
def evaluate_model(X_train, y_train, X_test, y_test, best_k):
    model = KNeighborsClassifier(n_neighbors=best_k)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    return accuracy, y_pred

# Step 6: Plotting Accuracy vs K
def plot_accuracy_vs_k(grid_search, best_k):
    k_values = [params['n_neighbors'] for params in grid_search.cv_results_['params']]
    scores = grid_search.cv_results_['mean_test_score']
    
    plt.figure(figsize=(8, 6))
    plt.plot(k_values, scores, marker='o', color='blue')
    plt.axvline(best_k, color='red', linestyle='--', label=f'Best k = {best_k}')
    plt.title("GridSearchCV: Cross-Validation Accuracy vs. k")
    plt.xlabel("k (n_neighbors)")
    plt.ylabel("Cross-Validation Accuracy")
    plt.legend()
    plt.grid(True)
    plt.show()

def main():
    # Generate and prepare data
    X, y = generate_data()
    X_train, X_test, y_train, y_test = split_data(X, y)
    X_train_scaled, X_test_scaled, _ = scale_data(X_train, X_test)

    # Tune hyperparameters
    grid_search = tune_hyperparameters(X_train_scaled, y_train)
    best_k = grid_search.best_params_['n_neighbors']
    print(f"✅ Best k found by GridSearchCV: {best_k}")

    # Evaluate final model
    accuracy, y_pred = evaluate_model(X_train_scaled, y_train, X_test_scaled, y_test, best_k)
    print(f"✅ Test accuracy with best k = {best_k}: {accuracy:.4f}")

    # Plot performance
    plot_accuracy_vs_k(grid_search, best_k)

if __name__ == "__main__":
    main()
