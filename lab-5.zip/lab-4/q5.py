import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier

# --- Generate training data ---
def generate_training_data(num_points=20, low=1, high=10, seed=42):
    np.random.seed(seed)
    X_train = np.random.uniform(low, high, size=(num_points, 2))
    y_train = np.where(X_train[:, 0] > X_train[:, 1], 0, 1)
    return X_train, y_train

# --- Generate test data as grid ---
def generate_test_data(step=0.1):
    x_vals = np.arange(0, 10 + step, step)
    y_vals = np.arange(0, 10 + step, step)
    xx, yy = np.meshgrid(x_vals, y_vals)
    test_points = np.c_[xx.ravel(), yy.ravel()]
    return test_points, xx, yy

# --- Predict using k-NN ---
def classify_with_knn(X_train, y_train, test_points, k):
    model = KNeighborsClassifier(n_neighbors=k)
    model.fit(X_train, y_train)
    return model.predict(test_points)

# --- Main logic to compare decision boundaries ---
def main():
    X_train, y_train = generate_training_data()
    test_points, xx, yy = generate_test_data()

    k_values = [1, 3, 5, 10]
    fig, axs = plt.subplots(2, 2, figsize=(14, 10))

    for ax, k in zip(axs.ravel(), k_values):
        y_pred = classify_with_knn(X_train, y_train, test_points, k)
        Z = y_pred.reshape(xx.shape)

        ax.contourf(xx, yy, Z, alpha=0.3, cmap=plt.cm.RdBu)
        ax.contour(xx, yy, Z, levels=[0.5], colors='black', linewidths=1.5)
        ax.set_title(f"k = {k}")
        ax.set_xlabel("Feature X")
        ax.set_ylabel("Feature Y")
        ax.grid(True)

    plt.suptitle("k-NN Decision Boundaries for Different k Values", fontsize=16)
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.show()

if __name__ == "__main__":
    main()
